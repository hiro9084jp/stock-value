#!/bin/bash
#
# the executable bit must be set for this file to be executable
# (check with ls -l runGUI.sh and look for the 'x' in -r.x... runGUI.sh)
# you may have to run this from a terminal: chmod +x runGUI.sh
#
#
# run Arelle in GUI mode
#
python3.1 MainGUI.pyw