arelle
======

.. toctree::
   :maxdepth: 4

   arelle

