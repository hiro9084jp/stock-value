'''
Created on Feb 19, 2011

Use this module to start Arelle in windowing interactive UI mode

@author: Mark V Systems Limited
(c) Copyright 2011 Mark V Systems Limited, All rights reserved.
'''

from arelle.XPathParser import main

main()