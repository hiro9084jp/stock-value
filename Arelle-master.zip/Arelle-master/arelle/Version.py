'''
This module represents the time stamp when Arelle was last built

@author: Mark V Systems Limited
(c) Copyright 2020 Mark V Systems Limited, All rights reserved.

'''
__version__ = '1.2020.05.10'  # number version of code base and date compiled
version = '2020-05-10 16:47 UTC'  # string version of date compiled
copyrightLatestYear = '2020'  # string version of year compiled
